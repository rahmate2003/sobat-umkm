"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { usePathname, useRouter } from "next/navigation"
import Cookies from "js-cookie"
import { refreshToken } from "@/lib/api/auth-service"
import { LoadingScreen } from "@/components/loading-screen"
export const AuthChecker = ({ children }: { children: React.ReactNode }) => {
  const router = useRouter()
  const pathname = usePathname()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const checkAndRefreshToken = async () => {
      const accessToken = Cookies.get("access_token")
      const refreshTokenValue = Cookies.get("refresh_token")

      // Skip for guest paths
      if (
        pathname.startsWith("/login") ||
        pathname.startsWith("/register") ||
        pathname.startsWith("/forgot-password")
      ) {
        setIsLoading(false)
        return
      }

      // No tokens - redirect to login
      if (!accessToken && !refreshTokenValue) {
        router.replace("/login")
        return
      }

      // If we have a refresh token but need to refresh access token
      if (refreshTokenValue && (!accessToken || isTokenExpired(accessToken))) {
        try {
          await refreshToken()
          setIsLoading(false)
        } catch (error: any) {
          console.error("Refresh failed:", error)

          // Handle specific error cases
          if (error.message === "REFRESH_TOKEN_EXPIRED") {
            router.replace("/login?reason=session_expired")
          } else if (error.message === "REFRESH_TOKEN_INVALID") {
            router.replace("/login?reason=session_expired")
          } else {
            router.replace("/login?reason=session_expired")
          }
          return
        }
      } else {
        setIsLoading(false)
      }
    }

    checkAndRefreshToken()
  }, [router, pathname])

  if (isLoading) {
    return <LoadingScreen />
  }

  return <>{children}</>
}

// Improved token expiration check with better error handling
function isTokenExpired(token: string): boolean {
  try {
    const base64Url = token.split(".")[1]
    if (!base64Url) return true

    const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/")
    const jsonPayload = decodeURIComponent(
      atob(base64)
        .split("")
        .map((c) => "%" + ("00" + c.charCodeAt(0).toString(16)).slice(-2))
        .join(""),
    )

    const payload = JSON.parse(jsonPayload)
    return payload.exp * 1000 < Date.now()
  } catch (error) {
    console.error("Error parsing token:", error)
    return true // If we can't parse the token, consider it expired
  }
}

